# How to Use

## Prerequisites
install nvidia-container-toolkit, see: https://docs.nvidia.com/datacenter/cloud-native/container-toolkit/latest/install-guide.html

## Start Service
```bash
bash ./start-service.sh <config-name>
```

## Request Serivce
### openai api
```bash
bash ./request-service-openai.sh <model>
```
## Stop Service
```bash
bash ./stop-service.sh <config-name>
```

## Table: config-name -> model & api-protocol
| config-name        | model              | api-protocol | graphics memory |
| ------------------ | ------------------ | ------------ | --------------- |
| llama3-70b_1       | Llama3-70B         | openai       | 96 GB           |
| llama3-70b_4       | Llama3-70B         | openai       | 96 GB           |
| qwen2-72b_1        | Qwen2-72B          | openai       | 96 GB           |
| qwen2-72b_4        | Qwen2-72B          | opena        | 96 GB           |
| codestral-22b-v0.1 | Codestral-22B-v0.1 | openai       | 24GB            |
| gemma2-27b_4       | Gemma-2-27B        | openai       | 96 GB           |
